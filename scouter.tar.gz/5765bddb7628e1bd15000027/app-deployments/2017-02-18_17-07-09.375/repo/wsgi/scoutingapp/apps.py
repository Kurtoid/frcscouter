from django.apps import AppConfig


class ScoutingappConfig(AppConfig):
    name = 'scoutingapp'
