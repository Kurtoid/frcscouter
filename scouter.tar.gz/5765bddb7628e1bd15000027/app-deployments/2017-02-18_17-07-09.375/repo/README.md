[![Code Climate](https://codeclimate.com/github/Kurtoid/frcscouter/badges/gpa.svg)](https://codeclimate.com/github/Kurtoid/frcscouter)
[![Test Coverage](https://codeclimate.com/github/Kurtoid/frcscouter/badges/coverage.svg)](https://codeclimate.com/github/Kurtoid/frcscouter/coverage)

By FRC Team 179

App hosted at http://scouter-team179.rhcloud.com/ on Openshift
